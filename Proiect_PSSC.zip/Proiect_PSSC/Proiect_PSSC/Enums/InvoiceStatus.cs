﻿namespace Proiect_PSSC.Enums;

public enum InvoiceStatus
{
    Pending,
    Paid,
    Cancelled
}