﻿namespace Proiect_PSSC.Enums;

public enum OrderStatus
{
    Pending,
    Validated,
    Invalid
}