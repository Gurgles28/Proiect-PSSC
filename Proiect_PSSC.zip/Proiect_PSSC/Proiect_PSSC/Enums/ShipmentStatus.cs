﻿namespace Proiect_PSSC.Enums;

public enum ShipmentStatus
{
    Pending,
    Shipped,
    Delivered
}